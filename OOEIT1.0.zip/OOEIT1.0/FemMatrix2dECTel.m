function [A,B] = FemMatrix2dECTel(g,E,zeta,Inj,C, Nel)


nI = length(Inj(:))/Nel;
Inj = reshape(Inj, Nel, nI);
ng = size(g,1);

B = zeros(ng+Nel-1,nI);
s = zeros(Nel,nI);

len = 0;
for ii=1:Nel
  len = len + length(E{ii});
end
% len3 = 3*len;
% 
% intS = zeros(len3,3);
% intM = zeros(len,3);
% rowS = zeros(len3,3);
% rowM = zeros(len,3);
% colS = zeros(len3,3);
% colM = zeros(len,3);

len2 = 2*len;

intS = zeros(len2,2);
intM = zeros(len,2);
rowS = zeros(len2,2);
rowM = zeros(len,2);
colS = zeros(len2,2);
colM = zeros(len,2);

%keyboard

mpos = 1;
spos = 1;
oldpos = 1;

% Loop through electrodes
for ii=1:Nel
  faces = E{ii};
    
  % Loop through faces on electrode ii
  for jj = 1:size(faces,1),
    ind = faces(jj,:); % face nodes
    
    gg = g(ind,:);
    
    %r_0=gg(1,1); % oletetaan, etta elektrodi on pystysuorassa
    %keyboard
    %rcidx = [ind;ind;ind];
    rcidx = [ind;ind];
%     
%     bb1 = triang2(gg);
%     bb2 = triang1(gg);
    
    bb1 = bound1(gg);
    bb2 = bound2(gg);
    
%     intS(spos:spos+2,:) = bb2/zeta(ii);
%     rowS(spos:spos+2,:) = rcidx.'; 
%     colS(spos:spos+2,:) = rcidx;   
    intS(spos:spos+1,:) = bb2/zeta(ii);
    rowS(spos:spos+1,:) = rcidx.'; 
    colS(spos:spos+1,:) = rcidx;   


    %intM(mpos,:) = -bb1.'/zeta(ii);
    intM(mpos,:) = -bb1.'/zeta(ii);
    colM(mpos,:) = ind; 
    
  
    B(ind,:) = B(ind,:) + bb1*ones(2,1)*Inj(ii,:)/zeta(ii);
    %B(ind,:) = B(ind,:) + 2*pi*r_0*bb1*ones(2,1)*Inj(ii,:)/zeta(ii);
    %s(ii,:)  = s(ii,:)  - elektro(gg)*Inj(ii,:)/zeta(ii);
    s(ii,:)  = s(ii,:)  - 2*bb1*Inj(ii,:)/zeta(ii); %%% 2*bb1 on facen pituus
    
%     spos = spos + 3;
%     mpos = mpos + 1;    
    
    spos = spos + 2;
    mpos = mpos + 1;    
  end
  rowM(oldpos:mpos-1,:) = ii;  
  oldpos = mpos;
end
S = sparse(rowS,colS,intS,ng,ng+Nel-1);
M = sparse(rowM,colM,intM,Nel,ng);

B(ng+1:end,:) = C'*s;

D = sparse(C'*C);
M = C'*M;
A = [S;M,D];
return
