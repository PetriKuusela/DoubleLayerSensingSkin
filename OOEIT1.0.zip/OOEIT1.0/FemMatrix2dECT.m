function [Arow,Acol,Aval]=FemMatrix2dECT(H,g,e);

A = 1;


gN=max(size(g));
HN=max(size(H));

k = 1;  
% Arow = zeros(4*HN,4);
% Acol = zeros(4*HN,4);
% Aval = zeros(4*HN,4);   

Arow = zeros(3*HN,3);
Acol = zeros(3*HN,3);
Aval = zeros(3*HN,3);   

% Gauss quadrature points and weights
%a=0.58541020;b=0.13819660;
%ip=[b b b;a b b;b a b;b b a];

% difference matrix of the (linear) basis functions
%L=[-1 1 0 0;-1 0 1 0;-1 0 0 1];
for ii=1:HN
  % Go through all tetrahedron
  ind = H(ii,:);
  gg = g(ind,:);
  ss = e(ind);
  %int = tetraLinSigma(gg,ss,ip,L);
  int = LinEpsilon2D(gg,ss);
  id = ind(:);
%   Arow(k:k+3,:) = [id id id id];
%   Acol(k:k+3,:) = [ind;ind;ind;ind];  
%   Aval(k:k+3,:) = int; 
  
  Arow(k:k+2,:) = [id id id];
  Acol(k:k+2,:) = [ind;ind;ind];  
  Aval(k:k+2,:) = int; 
  
  %k = k + 4;
  k = k + 3;
end  


return



































