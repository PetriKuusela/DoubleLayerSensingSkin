classdef PriorPositivityParabolic < handle
    %PositivityParabolic class contains a simple parabolic positivity
    %constraint and the required functions to be called by an inverse
    %problems solver (e.g. SolverLinesearch.m).
    %Supports real values, complex values, or a stacked complex model
    %(where input is [real(sigma); imag(sigma)])
    %
    %Author: Petri Kuusela 16.11.2021
    properties
        a %the constraint function value will be a*(x-minAcceptable)^2 for all x < minAcceptable
        minAcceptable%The minimum value of estimate that is not penalized
    end
    methods
        function obj = PriorPositivityParabolic(minAcceptable, valAt0)
            %Class constructor.
            %Input: minAcceptable = The minimum value of estimate which is
            %                       not penalized.
            %       valAt0 = What is the functional value at 0
            if length(minAcceptable) < 2%Only one value was given.
                minAcceptable = [minAcceptable; minAcceptable];%make both parameters have two elements
            end                                 %so that both can be called, even if only one was given.
            if length(valAt0) < 2               
                valAt0 = [valAt0; valAt0];
            end
            obj.minAcceptable = minAcceptable;
            obj.a = valAt0./(minAcceptable.^2);
        end
        function res = OptimizationFunction(self, sigma)
            if any(~isreal(sigma))%Complex values will be transformed into the stacked form
                sigma = [real(sigma);imag(sigma)];
            end
            if mod(length(sigma),2) == 0%The sigma might be a stacked complex model or not, works either way
                sigma1 = sigma(1:end/2);
                sigma2 = sigma(end/2+1:end);
                res = self.a(1)*sum((sigma1(sigma1<self.minAcceptable(1)) - self.minAcceptable(1)).^2) ...
                + self.a(2)*sum((sigma2(sigma2<self.minAcceptable(2)) - self.minAcceptable(2)).^2);%./self.minAcceptable^2;
            else%If length(sigma) is odd, it cannot be stacked complex model, so the first elements of parameters are enough
                res = self.a(1)*sum((sigma(sigma<self.minAcceptable(1)) - self.minAcceptable(1)).^2);
            end
        end
        function [Hess, grad] = GetHessAndGrad(self, sigma)
            iscomplex = 0;
            if any(~isreal(sigma))%Complex values will be transformed into the stacked form
                iscomplex = 1;
                sigma = [real(sigma);imag(sigma)];
            end
            if mod(length(sigma),2) == 0%The sigma might be a stacked complex model or not, works either way
                sigma1 = sigma(1:end/2);
                sigma2 = sigma(end/2+1:end);
                grad1 = zeros(length(sigma1),1);
                grad2 = zeros(length(sigma2),1);
                select1 = sigma1<self.minAcceptable(1);
                select2 = sigma2<self.minAcceptable(2);
                grad1(select1) = 2*self.a(1)*(sigma1(select1) - self.minAcceptable(1));
                grad2(select2) = 2*self.a(2)*(sigma2(select2) - self.minAcceptable(2));
                Hessvec1 = zeros(length(sigma1),1);
                Hessvec2 = zeros(length(sigma2),1);
                Hessvec1(select1) = 2*self.a(1);%./self.minAcceptable^2;
                Hessvec2(select2) = 2*self.a(2);%./self.minAcceptable^2;
                if iscomplex
                    Hess = diag([Hessvec1+1i*Hessvec2]);
                    grad = grad1 + 1i*grad2;
                else
                    Hess = diag([Hessvec1;Hessvec2]);
                    grad = [grad1;grad2];
                end
            else%If length(sigma) is odd, it cannot be stacked complex model, so the first elements of parameters are enough
                grad = zeros(length(sigma),1);
                select = sigma<self.minAcceptable(1);
                grad(select) = 2*self.a(1)*(sigma(select) - self.minAcceptable(1));
                Hessvec = zeros(length(sigma),1);
                Hessvec(select) = 2*self.a(1);%./self.minAcceptable^2;
                Hess = diag(Hessvec);
            end
        end
        
    end
end
        