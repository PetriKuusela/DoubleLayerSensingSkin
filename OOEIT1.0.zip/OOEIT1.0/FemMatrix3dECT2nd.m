function [Arow,Acol,Aval]=FemMatrix3dECT2nd(H,g,e);

A = 1;


gN=max(size(g));
HN=max(size(H));

k = 1;  
Arow = zeros(10*HN,10);
Acol = zeros(10*HN,10);
Aval = zeros(10*HN,10);   

% Gauss quadrature points and weights
wght=[1/24*ones(4,1)];
a=0.58541020;b=0.13819660;
intp = [a b b;b a b;b b a;b b b];
np = size(intp,1);
for ii=1:HN
  % Go through all tetrahedron
  ind = H(ii,:);
  gg = g(ind,:);
  ss = e(ind(1:4));
  int = tetra2ndLinSigma(gg,ss,wght,intp,np);
  Acol(k:k+9,:) = [ind;ind;ind;ind;ind;ind;ind;ind;ind;ind];ind=ind.';
  Arow(k:k+9,:) = [ind ind ind ind ind ind ind ind ind ind];  
  Aval(k:k+9,:) = int; 
  
  
  k = k + 10;
end  


return



































