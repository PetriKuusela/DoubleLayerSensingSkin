classdef PriorBarrierParabolic < handle
    %PositivityParabolic class contains a simple parabolic positivity
    %constraint and the required functions to be called by an inverse
    %problems solver (e.g. SolverLinesearch.m).
    %Supports real values, complex values, or a stacked complex model
    %(where input is [real(sigma); imag(sigma)])
    %
    %Author: Petri Kuusela 16.11.2021
    properties
        a %the constraint function value will be a*(x-bound)^2 for all x < bound
        bound%The boundary value of estimate that is not penalized
        upper %flag for having an upper constraint
    end
    methods
        function obj = PriorBarrierParabolic(bound, a, upper)
            %Class constructor.
            %Input: bound = The minimum value of estimate which is
            %                       not penalized.
            %       valAt0 = What is the functional value at 0
            if length(bound) < 2%Only one value was given.
                bound = [bound; bound];%make both parameters have two elements
            end                                 %so that both can be called, even if only one was given.
            if length(a) < 2               
                a = [a; a];
            end
            obj.bound = bound;
            obj.a = a;
            obj.upper = upper;
        end
        function res = OptimizationFunction(self, sigma)
            if any(~isreal(sigma))%Complex values will be transformed into the stacked form
                sigma = [real(sigma);imag(sigma)];
            end
            if mod(length(sigma),2) == 0%The sigma might be a stacked complex model or not, works either way
                sigma1 = sigma(1:end/2);
                sigma2 = sigma(end/2+1:end);
                if self.upper
                    res = self.a(1)*sum((sigma1(sigma1>self.bound(1)) - self.bound(1)).^2) ...
                    + self.a(2)*sum((sigma2(sigma2>self.bound(2)) - self.bound(2)).^2);%./self.bound^2;
                else
                    res = self.a(1)*sum((sigma1(sigma1<self.bound(1)) - self.bound(1)).^2) ...
                    + self.a(2)*sum((sigma2(sigma2<self.bound(2)) - self.bound(2)).^2);%./self.bound^2;
                end
            else%If length(sigma) is odd, it cannot be stacked complex model, so the first elements of parameters are enough
                if self.upper
                    res = self.a(1)*sum((sigma(sigma>self.bound(1)) - self.bound(1)).^2);
                else
                    res = self.a(1)*sum((sigma(sigma<self.bound(1)) - self.bound(1)).^2);
                end
            end
        end
        function [Hess, grad] = GetHessAndGrad(self, sigma)
            iscomplex = 0;
            if any(~isreal(sigma))%Complex values will be transformed into the stacked form
                iscomplex = 1;
                sigma = [real(sigma);imag(sigma)];
            end
            if mod(length(sigma),2) == 0%The sigma might be a stacked complex model or not, works either way
                sigma1 = sigma(1:end/2);
                sigma2 = sigma(end/2+1:end);
                grad1 = zeros(length(sigma1),1);
                grad2 = zeros(length(sigma2),1);
                if self.upper
                    select1 = sigma1>self.bound(1);
                    select2 = sigma2>self.bound(2);
                else
                    select1 = sigma1<self.bound(1);
                    select2 = sigma2<self.bound(2);
                end
                grad1(select1) = 2*self.a(1)*(sigma1(select1) - self.bound(1));
                grad2(select2) = 2*self.a(2)*(sigma2(select2) - self.bound(2));
                Hessvec1 = zeros(length(sigma1),1);
                Hessvec2 = zeros(length(sigma2),1);
                Hessvec1(select1) = 2*self.a(1);%./self.bound^2;
                Hessvec2(select2) = 2*self.a(2);%./self.bound^2;
                if iscomplex
                    Hess = diag([Hessvec1+1i*Hessvec2]);
                    grad = grad1 + 1i*grad2;
                else
                    Hess = diag([Hessvec1;Hessvec2]);
                    grad = [grad1;grad2];
                end
            else%If length(sigma) is odd, it cannot be stacked complex model, so the first elements of parameters are enough
                grad = zeros(length(sigma),1);
                if self.upper
                    select = sigma>self.bound(1);
                else
                    select = sigma<self.bound(1);
                end
                grad(select) = 2*self.a(1)*(sigma(select) - self.bound(1));
                Hessvec = zeros(length(sigma),1);
                Hessvec(select) = 2*self.a(1);%./self.bound^2;
                Hess = diag(Hessvec);
            end
        end
        
    end
end
        