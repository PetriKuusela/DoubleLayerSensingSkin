function int=phiiphij1D(g)

a = 1/6;
b = 1/3;
l=sqrt((g(1,1)-g(2,1))^2 + (g(1,2)-g(2,2))^2);
int=l*[b a;a b]; 

