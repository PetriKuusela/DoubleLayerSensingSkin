function int=triangLinSource(g,s,ip,L);

Jt = L*g;
int = sum(s)*abs(det(Jt));