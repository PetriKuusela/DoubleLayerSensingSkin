function [Arow,Acol,Aval,bvec]=FemMatrix3dECT(H,g,e);

A = 1;


gN=max(size(g));
HN=max(size(H));

k = 1;  
Arow = zeros(4*HN,4);
Acol = zeros(4*HN,4);
Aval = zeros(4*HN,4);   
bvec = zeros(gN,1);

% Gauss quadrature points and weights
a=0.58541020;b=0.13819660;
ip=[b b b;a b b;b a b;b b a];

% difference matrix of the (linear) basis functions
L=[-1 1 0 0;-1 0 1 0;-1 0 0 1];
for ii=1:HN
  % Go through all tetrahedra
  ind = H(ii,:);
  gg = g(ind,:);
  ss = e(ind);
  int = tetraLinSigma(gg,ss,ip,L);
  %int  = MexProject23(gg,ss,ip,L);
  id = ind(:);
  Arow(k:k+3,:) = [id id id id];
  Acol(k:k+3,:) = [ind;ind;ind;ind];  
  Aval(k:k+3,:) = int; 
  
  k = k + 4;
end  


return



































