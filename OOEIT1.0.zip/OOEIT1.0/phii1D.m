function int=phii1D(g)

a = 1/2;
l=sqrt((g(1,1)-g(2,1))^2 + (g(1,2)-g(2,2))^2);
int = l*[a;a];

