classdef ForwardMesh1st < handle
%This is a forward-mesh class.


    properties
        
        g   %the node points (an n x m array, each row containing one point)
        ng  %number of nodes
        gdim%dimension of the mesh (here 3)
        H   %the connectivity matrix (each row contains node indices (row number of g) that are in a single element
        nH  %number of elements
        E   %Electrode surface elements, nel x 1 cell array, each cell n x gdim array, indices refer to rows in g
        nel %number of electrodes in the system
        EC  %Element connections; each row i contains all elements (rows of H) such that contain node i.
        itof%inverse-to-forward mesh transform matrix (1 if no inverse mesh is specified.
        nginv%number of nodes in the inverse mesh
    end
    
    
    methods
        
        function obj = ForwardMesh1st(g, H, E)
            
            obj.g = g;
            obj.H = H;
            obj.E = E;
            obj.gdim = size(g,2);
            
            obj.ng = size(g,1);
            obj.nH = size(H,1);
            obj.nel = length(E);
            obj.SetEC();
            obj.itof = 1;
            
        end
        
        
        function s1 = ItoF(self, sigma)
            s1 = self.itof*sigma;
        end
        function JI = JacobianFtoI(self, J)
            JI = J*self.itof;
        end
        
        function A = SigmadPhiidPhij(self, sigma)
           %This function returns matrix A containing in its element (i,j)
           %the integral of sigma*grad(phi_i) dot grad(phi_j).
            
            sigma = self.itof*sigma;

            k = 1;  
            Arow = zeros(4*self.nH,4);
            Acol = zeros(4*self.nH,4);
            Aval = zeros(4*self.nH,4);

            % Gauss quadrature points and weights
            a=0.58541020;b=0.13819660;
            ip=[b b b;a b b;b a b;b b a];

            % difference matrix of the (linear) basis functions
            L=[-1 1 0 0;-1 0 1 0;-1 0 0 1];
            for ii=1:self.nH
              % Go through all tetrahedra
              ind = self.H(ii,:);
              gg = self.g(ind,:);
              ss = sigma(ind);
              int = tetraLinSigma(gg,ss,ip,L);
              id = ind(:);
              Arow(k:k+3,:) = [id id id id];
              Acol(k:k+3,:) = [ind;ind;ind;ind];  
              Aval(k:k+3,:) = int; 

              k = k + 4;
            end  
            
            A = sparse(Arow,Acol,Aval,self.ng+self.nel-1,self.ng+self.nel-1);

            
        end
        
        
        function [S, M, B] = EITElectrodeTerms(self)
            %This function returns matrices S and M, and vector B.
            %S is a cell array containing integrals phi_i*phi_j along
            %each electrode surfaces (one electrode per cell)
            %M contains integral phi_i on surface of electrode j
            %B contains the electrode areas in its elements.

            B = zeros(self.nel,1);

            M = zeros(self.ng, self.nel);

            S = cell(self.nel,1);
            % Loop through electrodes
            for ii=1:self.nel
              spos = 1;
              faces = self.E{ii};
              len = self.gdim*size(self.E{ii},1);
              intS = zeros(len,self.gdim);
              rowS = zeros(len,self.gdim);
              colS = zeros(len,self.gdim);
              % Loop through faces on electrode ii
              for jj = 1:size(faces,1)
                ind = faces(jj,:); % face nodes

                gg = self.g(ind,:);
                rcidx = repmat(ind, self.gdim, 1);

                if self.gdim == 3
                    bb1 = triang2(gg);
                    bb2 = triang1(gg);
                elseif self.gdim == 2
                    bb1 = phii1D(gg);
                    bb2 = phiiphij1D(gg);
                end

                intS(spos:spos+self.gdim-1,:) = bb2;
                rowS(spos:spos+self.gdim-1,:) = rcidx.'; 
                colS(spos:spos+self.gdim-1,:) = rcidx;   

                M(ind,ii) = M(ind,ii) + bb1;

                if self.gdim == 3
                    B(ii,:)  = B(ii,:) + elektro(gg);
                elseif self.gdim == 2
                    B(ii,:)  = B(ii,:) + ElectrodeArea1D(gg);
                end

                spos = spos + self.gdim;
              end
              S{ii} = sparse(rowS,colS,intS,self.ng,self.ng);
            end
            
        end
        
        function [Ai, Av] = GradientMatrix(self)
            %Computes all the basis function gradients of the 1st order
            %mesh to be used in calculating the Jacobian.
            %Based on earlier UEF codes. Modified to fit EITFEM-class by
            %Petri Kuusela 9.12.2021.
            ar = zeros(self.ng*12,self.gdim+1);
            ac = zeros(self.ng*12,self.gdim+1);
            av = zeros(self.ng*12,self.gdim+1);

            Ai = cell(self.ng,1);
            Av = cell(self.ng,1);

            % compute gradients
            for jj=1:self.ng

              El = self.EC(jj,self.EC(jj,:)>0);

              rid = 1;
              for ii=1:length(El)
                ind = self.H(El(ii),:); % Indices of the element
                gg=self.g(ind,:);

                idc = repmat(ind,self.gdim+1,1);
                idr = idc';
                
                L=[-ones(self.gdim,1) eye(self.gdim)];
                Jt=L*gg;
                dJt=abs(det(Jt)); % Tetrahedra volume
                G=Jt\L; % Gradients of each basis function
                GdJt=G'*G*dJt;

                if self.gdim == 3
                    int=1/24*GdJt;
                elseif self.gdim == 2
                    int=1/6*GdJt;
                end

                % temporary storage
                ar(rid:rid+self.gdim,:) = idr;
                ac(rid:rid+self.gdim,:) = idc;
                av(rid:rid+self.gdim,:) = int;
                rid = rid + 1 + self.gdim;      
              end     
              I = 1:(rid-1);

              S = sparse(ar(I,:),ac(I,:),av(I,:),self.ng,self.ng);
              [I,~] = find(S);

              L = unique(I);    
              Ai{jj} = L;             % symmetric assumption => no columns needed
              Av{jj} = full(S(L,L));
            end
        end
        
        function SetInverseMesh(self, imesh)
            
            
            %self.nginv = size(ginv,1);
            if size(imesh.g,2) == 2%Check the dimension of the inverse mesh
                self.itof = interpolatematrix2d_new(imesh.H, imesh.g, self.g(:,1:2));
            elseif size(imesh.g,2) == 3
                self.itof = interpolatematrix3d(imesh.H, imesh.g, self.g);
            else
                error(['Unfit second dimension of ginv: size(ginv,2) = ' num2str(size(ginv,2))]);
            end
            self.nginv = size(imesh.g,1);
            
        end
        
        
        %% Private functions
        %Pre-processing run by the constructor function of the class. These
        %are in general not run from outside the class
        function SetEC(self)
            %Sets self.EC, i.e. an array, for which each row i contains all
            %such element indices (i.e. rows of H) that the element contains the node i (i.e. row i of g).
            %currently the only use for self.EC is by self.GradientMatrix()
            counter = zeros(self.ng, 1);
            self.EC = zeros(self.ng, 4);
            for iH = 1:self.nH
                for in = 1:size(self.H,2)
                    id = self.H(iH, in);
                    counter(id) = counter(id) + 1;
                    self.EC(id, counter(id)) = iH;
                end
            end
            
        end
           
        
        
        
    end
    
    
    
    
    
    
    
    
    
    
    
end