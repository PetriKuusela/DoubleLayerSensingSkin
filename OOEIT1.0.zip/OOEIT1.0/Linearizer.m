classdef Linearizer < handle
    
    properties
        innerFunc
        linpoint
        lpval
        J
    end
    
    methods
        function obj = Linearizer(innerFunc)
            obj.innerFunc = innerFunc;
        end
        
        function setLinpoint(self, linpoint)
            self.linpoint = linpoint;
            self.lpval = self.innerFunc.SolveElectrodeCurrentsVec(linpoint);
            self.J = self.innerFunc.JacobianSolvingCurrents(linpoint);
        end
        function val = valAtPoint(self, sigest)
            val = self.lpval + self.J*(sigest-self.linpoint);
        end
        
        function J = matrix(self, sigest)
            J = self.innerFunc.matrix(self.linpoint);
        end
        
        function res = Fproximal(self, d, s)
            res = (d - s*self.innerFunc.Imeas)/(1+s);
        end
        function res = nextDual(self, d, s, sigest2)
            res = d + s*self.valAtPoint(sigest2);
        end    
        
    end
    
    
end