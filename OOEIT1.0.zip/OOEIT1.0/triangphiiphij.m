function int=triangphiiphij(g,c,ip,L, w)
%integrating with Gauss quadrature

phiatip = [1-ip(:,1)-ip(:,2),ip(:,1),ip(:,2)];
% Lasketaan c:n arvot integrointipisteiss�
coupl = phiatip*c;

Jt = L*g;
dJt = abs(det(Jt));
bint = phiatip'*diag(c.*w)*phiatip;
int = dJt*bint;
