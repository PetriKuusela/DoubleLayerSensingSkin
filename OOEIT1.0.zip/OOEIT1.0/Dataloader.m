function [Umeas, Imeas] = Dataloader(datamat_file, vincl, Nel, nslots, ms)
    
    if nargin == 1 || isempty(vincl)
        vincl = true(16, 16);
        vincl = vincl(:);
    end
    
    % Parametrit
    if nargin < 3 || isempty (Nel)
        Nel = 16; % Elektrodien lukum��r�
    end
    if nargin < 4 || isempty(nslots)
        nslots = 16; % Eksitaatioslottien lukum��r�
    end
    if nargin < 5 || isempty(ms)
        ms = 10; % Muuntosuhde. Laita t�h�n arvo "10" kun k�ytet��n 10:1 muuntajia               
    end

    % Luetaan data
    datafiles = getAllFiles(datamat_file);
    fileinds =( [1:length(datafiles)])';
    C_1 = loadAllFiles(datafiles(fileinds(1:end)));
    C1 = C_1;
    timestamps = C1(:,1); % Aikaleimat epoch-aikana
    C1(:,1) = []; % Poistetaan datasta aikaleimat ensimm�isest� sarakkeesta
    C1 = mean(C1); % Otetaan keskiarvo kaikista mittauksista ajan suhteen

    % Yksi rivi sis�lt��
    % samat arvot kuin Diagnostics-ohjelman "Show Data 1"-matriisissa. Data on
    % talletettu niin ett� kyseisen matriisin arvot ovat riveitt�in per�kk�in.
    % Eli ensimm�isen� on mittaukset ensimm�iselt� elektrodilta kultakin
    % slotilta. Seuraavaksi on mittaukset toiselta elektrodilta kultakin
    % slotilta. 

    IR = false(Nel^2,1); % Oletetaan yksinkertainen sy�tt�kuvio. Eli kukin 
                         % elektrodi sy�tt�� kerrallaan. IR on apuvektori
                         % sy�tt�jen indekseille
    IR(1:Nel+1:end) = true;
    IK = ~IR; % Apuvektori mittausten indekseille
    tIR = diag(true(Nel,1));
    tIK = ~tIR;
    % Nyt IK sis�lt�� indeksit mittauksille ja IR sy�t�ille
    data_tmp = reshape(C1,nslots,Nel);
    data_tmp = data_tmp';
    %data = data_tmp(:);
    CurrentPattern = zeros(Nel,Nel);
    CurrentPattern(tIK) = data_tmp(tIK) * ms;
    Cexc = -sum(CurrentPattern,1);
    CurrentPattern(tIR) = Cexc;
    Uel = zeros(Nel,Nel);
    Uel(tIR) = data_tmp(tIR) * (1/ms);

    load('Rocsole/MeasPattern.mat');
    Nmeas = size(MeasPattern,2);
    tCp = CurrentPattern;
    CurrentPattern = Uel /100;

    %mincl = tIK;% + tIR;
    %mincl = tril(tIK);
    %vincl  = mincl(:);
    %tCpt = tCp';
    Uel = tCp(:);
    %Uelt = tCpt;
    %Uel = -0.5*(Uel(vincl) + Uelt(vincl));
    Uel = Uel(vincl);

    
    
    Umeas = CurrentPattern;
    Imeas = Uel;


end