classdef PriorCorrelatedTotalVariation
%PriorCorrelatedTotalVariation class contains a TV prior and the required functions
%for it to be called by an inverse problem solver -class (e.g.
%SolverLinesearch.m). Correlation of real and imaginary part is done by
%having them under the same squareroot.
%Supports real values(No it doesn't), complex values, or a stacked complex model
%(where input is [real(sigma); imag(sigma)])
%
%Author: Petri Kuusela 16.11.2021
    
    properties
        gradphi     %The gradients of all basis functions. A cell array with each cell containing gradients inside one element
        H           %The elements of the reconstruction mesh
        g           %The nodes of the reconstruction mesh
        nH          %Number of elements
        ng          %Number of nodes
        alpha       %The "strength" coefficient of TV
        beta        %The smoothing parameter
        Areas       %A vector containing the area of each element
        D           %This is required only for Chambolle-Pock type solvers
    end
    
    methods
        
        function obj = PriorCorrelatedTotalVariation(g, H, ec, ef, beta)
            %Class constructor.
            %Inputs: g = the nodes of the reconstruction mesh
            %        H = the elements of the reconstruction mesh
            %        ec = expected change of the estimate (can have two
            %        elements if different coefficients are to be used for
            %        conductivity and permittivity.)
            %        ef(optional) = extra factor which multiplies alpha
            %        beta(optional) = the smoothing constant
            %NOTE: if you want to set alpha yourself, you can change it
            %directly after initiating the object.
            %NOTE2: Older version of this class constructor took in alpha
            %as an argument, so that usage may be found in older drivers.
            
            if nargin < 4 || isempty(ef)
                ef = 1;
            end
            if nargin < 5 || isempty(beta)
                beta = 1e-4;
            end
            
            obj.g = g;
            obj.H = H;
            mesh_a = (max(max(g(:,1)))-min(min(g(:,1))))*(max(max(g(:,2)))-min(min(g(:,2))))/size(H,1);%roughly the element area of the mesh
            mesh_c = sqrt(2*mesh_a);%roughly the element size of mesh
            egrad = ec./mesh_c;%expected gradient
            tvp = 0.975;
            alpha = -ef.*log(1-tvp)./(mesh_a*egrad);
            obj.alpha = alpha;
            obj.beta = beta;
            
            obj.ng = size(g, 1);
            obj.nH = size(H, 1);
            [obj.gradphi, obj.Areas, obj.D] = obj.ComputeGrads2D(g,H);
            
        end
        
        
        function res = OptimizationFunction(self, sigest)
            %This is the function called by the inverse problem solver to
            %get the value of the function which is to be minimized.
            %Input: sigest is the conductivity, can be either real or
            %       complex, or stacked so that real and imaginary part are
            %       on top of each other.
            
            if any(~isreal(sigest))%A complex conductivity, transform it into the stacked form
                sigest = [real(sigest); imag(sigest)];%Assume that real and imag parts are independent
            end
            if length(sigest) == 2*self.ng%We have the stacked form, i.e. [real(sigest); imag(sigest)]
                a = self.alpha;%Store alpha in a temporary variable for possible manupulations
                gradsigma1 = self.ComputeGrads(sigest(1:end/2));%Compute gradients separately for real and imag parts
                gradsigma2 = self.ComputeGrads(sigest(end/2+1:end));
                if length(a) < 2
                    a = [a;a];%If only one alpha has been given
                end
                res = sum(self.Areas.*sqrt(a(1)^2*sum(abs(gradsigma1).^2, 2) + a(2)^2*sum(abs(gradsigma2).^2, 2)+self.beta));
            else%We have real-valued sigma
                gradsigma = self.ComputeGrads(sigest);
                res = self.alpha*sum(self.Areas.*sqrt(sum(abs(gradsigma).^2, 2)+self.beta));
            end
        end
        
        function [Hess, grad] = GetHessAndGrad(self, sigest)
            %Compute the Hess-matrix and gradient of the optimization
            %function. This function is called by the inverse problem
            %solver.
            %Input: sigest is the conductivity, can be either real or
            %       complex, or stacked so that real and imaginary part are
            %       on top of each other.
            
            iscomplex = 0;%note that this does not indicate complex stacked model!
            if any(~isreal(sigest))%A complex conductivity, transform it into the stacked form
                sigest = [real(sigest); imag(sigest)];%Assume that real and imag parts are independent
                iscomplex = 1;%This flag is needed to know that we have to undo the stacking in the end
            end
            if length(sigest) == 2*self.ng%We have the stacked form, i.e. [real(sigest); imag(sigest)]
                a = self.alpha;%Store alpha in a temporary variable for possible manupulations
                gradsigma = cell(2,1);
                gradsigma{1} = self.ComputeGrads(sigest(1:end/2));%Compute gradients separately for real and imag parts
                gradsigma{2} = self.ComputeGrads(sigest(end/2+1:end));
                grad = zeros(2*self.ng,1);%initialize arrays for gradient and Hess-matrix
                Hvals = zeros(12*self.ng,1);%Hess matrix is collected in sparse form
                HindsI = zeros(12*self.ng,1);
                HindsJ = zeros(12*self.ng,1);
                if length(a) < 2
                    a = [a;a];%If only one alpha has been given
                end
            else%We have a real-valued sigma
                a = self.alpha;
                gradsigma = {self.ComputeGrads(sigest)};%gradsigma is a cell-array to facilitate similart treatment as in complex case
                grad = zeros(self.ng,1);%initialize arrays for gradient and Hess-matrix
                Hvals = zeros(6*self.ng,1);%Hess matrix is collected in sparse form
                HindsI = zeros(6*self.ng,1);
                HindsJ = zeros(6*self.ng,1);
            end
            
            %This version works only for complex sigma!
            II = 1;%index for collecting the Hess-values in sparce matrix            
            for ik = 1:length(gradsigma)%If we have a complex sigma, the following will be repeated for real and imag parts separately
                
                %This block calculates the gradient of the TV functional
                tdsigma = cell(2,1);
                for ii=1:self.nH
                    tdgrads = self.gradphi{ii};%The gradients of the basis functions in element ii
                    tinds = self.H(ii,:) + (ik-1)*self.ng;%node indices that are the verices of element ii
                    tdsigma{1} = gradsigma{1}(ii,:);%The gradient of sigma in element ii
                    tdsigma{2} = gradsigma{2}(ii,:);
                    gnorm = 1/sqrt(a(1)^2*sum(tdsigma{1}.^2) + a(2)^2*sum(tdsigma{2}.^2) + self.beta);%1/sqrt part of the gradient
                    tdot = tdgrads*tdsigma{ik}';%The dot product of gradients of basis functions and gradient of sigma
                    %tempdiff only matters when coupling the real and imag parts:
                    grad(tinds) = grad(tinds) + a(ik)^2*gnorm.*tdot.*self.Areas(ii);%Add the terms to the relevant gradient elements
                end

                %This block calculates the Hess-matrix of the TV functional
                for ii=1:self.nH
                    tdgrads = self.gradphi{ii};%The gradients of the basis functions in element ii
                    tinds = self.H(ii,:) + (ik-1)*self.ng;%node indices that are the vertices of element ii
                    tdsigma{1} = gradsigma{1}(ii,:);%The gradient of sigma in element ii
                    tdsigma{2} = gradsigma{2}(ii,:);%The gradient of sigma in element ii
                    gnorm = (a(1)^2*sum(tdsigma{1}.^2) + a(2)^2*sum(tdsigma{2}.^2) + self.beta)^(-0.5);%These are parts of the Hessian
                    gnorm2 = (a(1)^2*sum(tdsigma{1}.^2) + a(2)^2*sum(tdsigma{2}.^2) + self.beta)^(-1.5);
                    
                    for jj=1:3
                        for kk=1:3
                            phii = tdgrads(jj,:);%grad? of basis function_i
                            phij = tdgrads(kk,:);%grad? of basis function_j
                            f = phii*phij'*gnorm;
                            h = -a(ik)^2*(tdsigma{ik}*phii'*gnorm2*tdsigma{ik}*phij');%Check how the "a"s should be!
                            Hvals(II) = a(ik)^2*(f + h).*self.Areas(ii);
                            HindsI(II) = tinds(jj);
                            HindsJ(II) = tinds(kk);
                            II = II + 1;
                        end
                    end
                end

            end
            
            
            if iscomplex %The original data is in complex non-stacked model
                grad = grad(1:end/2) + 1i*grad(end/2+1:end);
                Hess = sparse(HindsI(HindsI<=self.ng), HindsJ(HindsJ<=self.ng),Hvals(HindsI<=self.ng));
                Hess = Hess + 1i*sparse(HindsI(HindsI>self.ng)-self.ng, HindsJ(HindsJ>self.ng)-self.ng,Hvals(HindsI>self.ng));
            else
                Hess = sparse(HindsI,HindsJ, Hvals);
            end
        end
        
        function gradsigma = ComputeGrads(self, sigest)
            %Compute the gradients of the sigma, using the pre-computed
            %self.gradphi.
            N = size(self.gradphi,1);
            gradsigma = zeros(N,2);
            for ii=1:N
                sigmas = sigest(self.H(ii,:));
                grads = self.gradphi{ii};
                gradsigma(ii,:) = sigmas(1)*grads(1,:) +  sigmas(2)*grads(2,:) +  sigmas(3)*grads(3,:);
            end
        end
        
        function [gradphi, areas, R] = ComputeGrads2D(self, g,H)
            % Computes the spatial gradients of the linear basis functions
            % Also calculates the area of each element, and R, which is
            % only needed for Chambolle-Pock type solvers.
            N = size(H,1);
            gN = size(g,1);
            gradphi = cell(N,1);
            areas = zeros(N,1);
            gradsigma = zeros(N,2);
            L = [-1 1 0; -1 0 1];
            R = sparse(2*N,gN);
            for ii=1:N
                tind = H(ii,:);
                X = g(H(ii,:),:);
                Jt = L*X;
                areas(ii) = 1/2*abs(det(Jt));
                grads = Jt\L;
                grads = grads';
                gradphi{ii} = grads;
                R(ii,tind) = grads(:,1)';%These are only needed for Chambolle-Pock type solvers
                R(end/2 + ii,tind) = grads(:,2)';%Should these be multiplied by areas? 
            end

        end


        %%
        %The rest are for Chambolle-Pock type inverse problem solvers and
        %are most likely outdated
        
        function D = matrix(self, sigma)
            D = self.D;
        end
        function res = Fproximal(self, d, s)
            dl = sqrt(d(1:end/2).^2 + d(end/2+1:end).^2);
            dl = [dl;dl];
            res = self.alpha*self.Areasx2.*d./max(self.alpha*self.Areasx2, dl);      
        end
        function res = nextDual(self, d, s, sigest2)
            res = d + self.matrix(sigest2)*sigest2*s;
        end 
        
        
    end 
    
end