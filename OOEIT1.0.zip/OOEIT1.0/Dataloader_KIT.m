function [Umeas, Imeas] = Dataloader_KIT(dataname, absB)


    load(dataname);
    Umeas = measurements.voltages;
    Imeas = measurements.patterns.injectedCurrents(:);
    %Reset the potential zero so that sum(U) inside an injection is zero
    for ii = 1:16
        Umeas((32*(ii-1)+1):(32*ii)) = Umeas((32*(ii-1)+1):(32*ii)) -mean(real(Umeas((32*(ii-1)+1):(32*ii))));
    end
    
    %Umeas = sqrt(real(Umeas).^2 + imag(Umeas).^2 + absB);
    Umeas = sqrt(Umeas(1:end/2).^2 + Umeas(end/2+1:end).^2 + absB);
    Imeas = Imeas(:);
    


end

