classdef Plotter < handle
%A Plotter class that can be assigned to inverse problem solver (e.g.
%SolverLinesearch.m) to plot the estimate in between the iterations.
    
    properties
        g       %The array of node co-ordinates
        H       %The elements of the mesh
        g1      %The nodes of the forward mesh (used to plot the electrodes)
        elfaces %A cell array containing electrode nodes referring to g1
        cm      %colormap
        scales  %the scales to multiply the estimates to get the plotted values
        fig     %A figure handle for conductivity
        fig2    %A figure hadle for permittivity
        plotel  %A flag: do we want to plot the electrodes?
    end
    
    methods
        
        function obj = Plotter(g, H, g1, elfaces)
            %Class constructor.
            %Input: g and H define the mesh we want to plot on
            %       g1 and elfaces(optional) define where the electrodes
            %       are plotted
            obj.g = g;
            obj.H = H;
            obj.cm = jet;
            obj.fig = figure();
            %obj.fig2 = figure();%create this only when needed at run-time
            if nargin > 3
                obj.elfaces = elfaces;
                obj.g1 = g1;
            end
            obj.plotel = 0;
            obj.scales = 1;
        end
        
        function plot(self, sigma, minmaxvals)
            %The basic plot function to plot sigma. The colorbar scale can
            %be given in minmaxvals = [minval maxval].
            
            
            %First check if we try to plot the electrodes without having
            %given the necessary variables:
            if self.plotel && (isempty(self.elfaces) || isempty(self.g1))
                warning('Cannot plot electrodes since elfaces or g1 is not set');
                self.plotel = 0;
            end
            
            %Set the figure we want to plot on:
            set(0, 'CurrentFigure', self.fig);
            clf;
            if any(~isreal(sigma))%are there complex values?
                sigma = [real(sigma); imag(sigma)];
            end
            if length(sigma) == 2*length(self.g)%This is a stacked complex model
                if isempty(self.fig2)%Make sure we have the second figure as well
                    self.fig2 = figure();
                    %Set the focus back on the first fig:
                    set(0, 'CurrentFigure', self.fig);
                    clf;
                end
                
                %Apply the scales:
                if length(self.scales) == 2
                    sigma(1:end/2) = self.scales(1)*sigma(1:end/2);
                    sigma(end/2+1:end) = self.scales(2)*sigma(end/2+1:end);
                else
                    sigma = sigma.*self.scales;
                end
                
                sigma2 = sigma(end/2+1:end);
                sigma = sigma(1:end/2);
                if nargin > 2
                    minval = minmaxvals(1);
                    maxval = minmaxvals(2);
                else
                    minval = min(sigma);
                    maxval = max(sigma);
                end
                
                if size(self.g,2) == 2
                    fh = trisurf(self.H, self.g(:,1), self.g(:,2), sigma);%This is the line that does the main plotting
                    view(2);
                    set(fh, 'edgecolor', 'none');%no edges
                    set(fh, 'FaceColor', 'interp');%smooth colors between elements
                    colormap(get(fh,'parent'), self.cm);%set colormap
                elseif size(self.g,2) == 3
                    tr = Otsu(sigma, 256, 0);
                    sel = ~any(sigma(self.H)<tr,2);
                    fh = tetramesh(self.H(sel,:),self.g);
                end
                if maxval > minval
                    set(get(fh,'parent'),'CLim',[minval maxval]);
                else%Prevent error when plotting a constant sigma
                    set(get(fh,'parent'),'CLim',[minval-1e-6 maxval+1e-6]);
                end
                axis('square')
                colorbar;
                %Plot the electrodes:
                if self.plotel
                    hold on;
                    for iel = 1:length(self.elfaces)
                        for it = 1:length(self.elfaces{iel})
                            plot(self.g1(self.elfaces{iel}(it,:), 1), self.g1(self.elfaces{iel}(it,:), 2), 'k-', 'LineWidth', 5);
                        end
                    end
                    hold off;
                end
                title('Conductivity');

                %The same for complex part (permittivity)
                set(0, 'CurrentFigure', self.fig2);
                clf;
                sigma = sigma2;
                if nargin > 2
                    minval = minmaxvals(1);
                    maxval = minmaxvals(2);
                else
                    minval = min(sigma);
                    maxval = max(sigma);
                end
                if size(self.g,2) == 2
                    fh = trisurf(self.H, self.g(:,1), self.g(:,2), sigma);%This is the line that does the main plotting
                    view(2);
                    set(fh, 'edgecolor', 'none');%no edges
                    set(fh, 'FaceColor', 'interp');%smooth colors between elements
                    colormap(get(fh,'parent'), self.cm);%set colormap
                elseif size(self.g,2) == 3
                    tr = Otsu(sigma, 256, 0);
                    sel = ~any(sigma(self.H)<tr,2);
                    fh = tetramesh(self.H(sel,:),self.g);
                end
                if maxval > minval
                    set(get(fh,'parent'),'CLim',[minval maxval]);
                else
                    set(get(fh,'parent'),'CLim',[minval maxval+1e-6]);
                end
                axis('square')
                colorbar;
                %Plot the electrodes:
                if self.plotel
                    hold on;
                    for iel = 1:length(self.elfaces)
                        for it = 1:length(self.elfaces{iel})
                            plot(self.g1(self.elfaces{iel}(it,:), 1), self.g1(self.elfaces{iel}(it,:), 2), 'k-', 'LineWidth', 5);
                        end
                    end
                    hold off;
                end
                title('Permittivity');
            
            else%We do not have a stacked or complex model
                
                %Set the figure we want to plot on:
                %set(0, 'CurrentFigure', self.fig);%This is done already!
                %clf;
                
                %Apply the scales:
                sigma = sigma.*self.scales;
                %if need be, see comments on the similar code snippets above
                if nargin > 2
                    minval = minmaxvals(1);
                    maxval = minmaxvals(2);
                else
                    minval = min(sigma);
                    maxval = max(sigma);
                end
                if size(self.g,2) == 2
                    fh = trisurf(self.H, self.g(:,1), self.g(:,2), sigma);%This is the line that does the main plotting
                    view(2);
                    set(fh, 'edgecolor', 'none');%no edges
                    set(fh, 'FaceColor', 'interp');%smooth colors between elements
                    colormap(get(fh,'parent'), self.cm);%set colormap
                elseif size(self.g,2) == 3
                    tr = Otsu(sigma, 256, 0);
                    %sel = ~any(sigma(self.H)<tr,2);
                    sel = true(size(self.H,1),1);
                    fh = tetramesh(self.H(sel,:),self.g, sum(sigma(self.H(sel,:)),2));
                end
                if maxval > minval
                    set(get(fh,'parent'),'CLim',[minval maxval]);
                else
                    set(get(fh,'parent'),'CLim',[minval-1e-6 maxval+1e-6]);
                end
                axis('square')
                colorbar;
                if self.plotel
                    hold on;
                    for iel = 1:length(self.elfaces)
                        for it = 1:length(self.elfaces{iel})
                            plot(self.g1(self.elfaces{iel}(it,:), 1), self.g1(self.elfaces{iel}(it,:), 2), 'k-', 'LineWidth', 5);
                        end
                    end
                    hold off;
                end
                
            end
                
        end
        
        
    end    
    
    
end