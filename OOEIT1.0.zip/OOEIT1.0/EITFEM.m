classdef EITFEM < handle
%EITFem class contains a 3D FEM solver of a complete electrode model.
%Support of any kind of mesh is achieved by having the mesh in a separate
%class. More complex behaviour can be added by inheriting this class (for
%example multi frequency EIT, absolute value EIT...)
%
%This class implements the functions required for it to be assigned to an
%inverse problem solver -class (e.g. SolverLinesearch.m).
%
%TODO:
%-should epsilon correction be added at SolveForward, or at SolveForwardVec
%(currently it is at the latter)?
%
%Author: Petri Kuusela, 9.12.2022
    
    
    
    properties
        fmesh   %forward mesh
        fmesh2  %optional second mesh for calculating jacobian (not in use now, I think?)
        C       %C matrix used to construct the basis function of electrode potentials/currents (nel x nel-1 array)
        zeta    %Contact impedances of electrodes, nel x 1 array
        vincl   %A logical array (ng x 1) indicating which measurement values are used
        IDmeas  %The independent measurements (i.e. currents or potentials, which are set on electrodes)
        Dmeas   %The dependent measurements (i.e. currents or potentials, which are measured as a result)
        A       %FEM matrix
        Ai      %The index decomposition used in caluclating the Jacobian
        Av
        %P1st    %A mapping from inverse to 1st order mesh (sigma_1st = P1st*sigma_inv)
        intS    %integral values used for the FEM matrix
        intM    %integral values used for the FEM matrix
        intB    %integral values used for the FEM matrix
        S       %The part of matrix A dependent on electrodes
        b       %Rhs of FEM equation A*Pot = b
        recalc  %A flag for recalculating everything in the FEM matrix. e.g. set to 1 if zetas are modified.
        InvGamma_n %inverse of covariance matrix Gamma of the measurement values
        Ln      %chol(InvGamma_n)
        Pot     %The FEM solution A\b
        QC      %Matrix used to extract solutions from Pot (i.e. [0 0; 0 C]?)
        sigmamin%The minimum cutoff value for conductivity, all values below sigmamin will be set to sigmamin
        scales  %Scaling of each sigma value used before solving FEM. If len(scales) == 2 the first value scales real(sigma) and second imag(sigma)
        mode    %'current' or 'potential', which one is injected (the other one is solved by solving CEM)
        eps     %epsilon-correction epsilon, added to every FEM result
        stackOutput %A flag: is the output a stacked complex model
        omega   %signal (angular)frequency
    end %end properties
    
    
    methods
        
        function obj = EITFEM(fmesh)
            %Class constructor. Input (fmesh) is the forward mesh of
            %the FEM solver (see properties-section for details).
            obj.fmesh = fmesh;
            [obj.Ai, obj.Av] = fmesh.GradientMatrix();
            
            %populate necessary properties with default values
            [obj.intS, obj.intM, obj.intB] = fmesh.EITElectrodeTerms();
            obj.C = [ones(1,fmesh.nel-1);-eye(fmesh.nel-1)];
            idr = repmat((1:fmesh.nel)',1,fmesh.nel-1);
            idc = repmat(fmesh.ng+(1:(fmesh.nel-1)),fmesh.nel,1);
            obj.QC = sparse(idr,idc,obj.C,fmesh.nel,fmesh.ng+fmesh.nel-1);
            obj.sigmamin = 1e-6;
            obj.vincl = true(fmesh.nel*fmesh.nel,1);
            obj.mode = 'potential';%potential injection system
            obj.IDmeas = diag(ones(fmesh.nel,1));
            obj.IDmeas = obj.IDmeas(:);
            obj.eps = 0;
            obj.scales = 1;
            obj.zeta = 1e-9*ones(fmesh.nel,1);
            obj.stackOutput = 0;
            obj.recalc = 1;
            obj.omega = 0;
        end %end constructor
        
        %% Forward solutions
        %The general FEM solver-functions with varying outputformats. The
        %self.mode property is used to check whether currents or potentials
        %are to be solved.
        
        
        function elval = SolveForward(self, sigma, noscf)
            %Solve the potentials or currents for given sigma and angular
            %frequency omega.
            %Input:     sigma   = The conductivity distribution
            %           mode    = 'current' or 'potential', which one is
            %                     injected
            %                     
            %           noscf   = Do not use scaling of sigma
            %Output: elval =  the currents or potentials for a single
            %                 frequency in matrix (and complex) form
            %                 computed using FEM  
            
            if nargin < 3 || isempty(noscf)
                noscf = 0;
            end
            
                
            %Check formats of sigma and self.scales and lift any
            %values that are negative or too close to 0.
            sigma = self.LiftSigma(sigma);
            
            %Scale sigma to avoid numerical problems:
            if noscf
                scf = 1;%Use scf=1 for updating the intermidiate steps  used in calculating Jacobian
            else
                scf = 1;%abort scf for continuously causing bugs!!!
                %scf = abs(mean(sigma));%This is used to avoid some numerical problems following from poorly scaled sigma.
            end
            sigma = sigma./scf;%This is not the optimal scaling, and may not work in some extreme cases
            zetas = self.zeta.*scf;
            
            
            %Start forming the EIT-matrix
            A0 = self.fmesh.SigmadPhiidPhij(sigma);
            
            if self.stackOutput
                Inj = self.IDmeas(1:end/2) + 1i*self.IDmeas(end/2+1:end);
            else
                Inj = self.IDmeas;
            end
            if self.recalc
                self.S = self.intS{1}/zetas(1);
                for ii=2:length(self.intS)
                    self.S = self.S + self.intS{ii}/zetas(ii);
                end
                if strcmp(self.mode, 'potential')
                    self.S = [self.S zeros(size(self.S,1), size(self.C,2)); -self.C'*diag(1./zetas)*self.intM' self.C'*self.C];
                    ninj = numel(Inj)/self.fmesh.nel;
                    self.b = zeros(size(self.S,1), ninj);
                    InjMat = reshape(Inj, self.fmesh.nel, ninj);
                    self.b(1:self.fmesh.ng,:) = self.intM*diag(1./zetas)*InjMat;
                    self.b(end-self.fmesh.nel+2:end,:) = self.b(end-self.fmesh.nel+2:end,:) - self.C'*(diag(self.intB./zetas)*InjMat);
                elseif strcmp(self.mode, 'current')
                    C2 = -self.C'*diag(1./zetas)*self.intM';
                    self.S = [self.S C2'; C2 -self.C'*diag(self.intB./zetas)*self.C];%check the sign of intB
                    ninj = numel(Inj)/self.fmesh.nel;
                    self.b = zeros(size(self.S,1), ninj);
                    InjMat = reshape(Inj, self.fmesh.nel, ninj);
                    self.b(end-ninj+2:end,:) = self.C'*InjMat;
                else
                    error(['Unrecognized solver mode: ' self.mode]);
                end
                self.recalc = 0;
            end
            
            self.A = A0 + self.S;

            self.Pot = self.A\self.b;

            elval = self.QC*self.Pot;
            if strcmp(self.mode, 'potential')
                elval = elval*scf;%The results have to be scaled in the opposite direction as the conductivity was scaled in the beginning
            elseif strcmp(self.mode, 'current')
                elval = elval/scf;%The results have to be scaled in the same direction as the conductivity was scaled in the beginning
            else
                error(['Unrecognized solver mode: ' self.mode]);
            end
            
        end %end solveForward
        
        
        function vec = SolveForwardVec(self, sigma)
            %Solve FEM with given sigma.
            %output: vec = the currents or potentials in vector format
            %              computed using FEM
            
            vec = self.SolveForward(sigma);
            vec = vec(:);
            vec = vec(self.vincl);
            vec = vec + self.eps;%Add a given constant (scalar or vector) to the results
            if self.stackOutput
                vec = [real(vec); imag(vec)];
            end
        end %end solveForwardVec
        
        
        
        
        %% Inverse problem functions
        %The functions used in inverse problem, i.e. Residual, gradient and
        %Hess calculations, and setting the noise levels.
        
        function res = OptimizationFunction(self, sigma)
            %Calculate the residual of the forward problem, which is to be
            %minimized (in addition to the regularization) when solving the
            %inverse problem. This function is called by the inverse
            %problem solver (e.g. SolverLinesearch.m)        
           
            elval = self.SolveForwardVec(sigma);
            res = 0.5*sum((self.Ln*(abs(self.Dmeas - elval))).^2);
        end
        
        function SetInvGamma(self, meas_noise_coef_e, meas_noise_coef2)
            %Calculate and set the inverse of covariance matrix based on
            %the noise levels given as arguments.
            %Input: meas_noise_coef_e = a constant noise level for all
            %       measurements. This coefficient is scaled to the
            %       difference of minimum and maximum measurement values to
            %       get the actual noise level. Can be a scalar or vector
            %       of length self.omegas having a different coefficient
            %       for different frequencies. A complex value can be used
            %       to determine different values for real and imag parts
            %       of measurements.
            %
            %       meas_noise_coef2(optional) = relative noise level of the
            %       measurements. This is multiplied by the absolute value
            %       of each measurement to get the noise level of that
            %       measurement. Can be a scalar or vector
            %       of length self.omegas having a different coefficient
            %       for different frequencies. A complex value can be used
            %       to determine different values for real and imag parts
            %       of measurements.
            %
            %       The two types of noise above are added together.
            %NOTE: This does not add noise to the solution of the forward
            %problem! This just calculates the Weighing matrix used in the
            %inverse problem.
            
            %Check the optional arguments:
            if nargin < 3 || isempty(meas_noise_coef2)
                meas_noise_coef2 = 0;
            end
            
            nmeas = numel(self.Dmeas);            
            
            if any(~isreal(meas_noise_coef_e))%for comments on the code see the else block
                %In this block we assume frequency by frequency stacked
                %real and imag measurements and that the coefficients real
                %and imag parts correspond to the measurements real and
                %imag parts
                if self.stackOutput
                    nmeas = nmeas/2;%nmeas is the length of real or imag part alone
                end
                if ~any(~isreal(meas_noise_coef2))%no imag parts in coef2
                    meas_noise_coef2 = meas_noise_coef2 + 1i*meas_noise_coef2;
                end
                var_meas = zeros(2*nmeas,1);
                %real:
                select = 1:nmeas;
                var_meas(select) = (real(meas_noise_coef_e)*(max(max(abs(self.Dmeas(select))))-min(min(abs(self.Dmeas(select))))))^2;
                var_meas(select) = var_meas(select) + (real(meas_noise_coef2)*(abs(self.Dmeas(select)) - min(min(abs(self.Dmeas(select)))))).^2;
                %imag:
                select = nmeas+1:2*nmeas;
                var_meas(select) = (imag(meas_noise_coef_e)*(max(max(abs(self.Dmeas(select))))-min(min(abs(self.Dmeas(select))))))^2;
                var_meas(select) = var_meas(select) + (imag(meas_noise_coef2)*(abs(self.Dmeas(select)) - min(min(abs(self.Dmeas(select)))))).^2;
                Gamma_n = diag(var_meas(:));
                self.InvGamma_n = sparse(inv(Gamma_n));
                self.Ln = chol(self.InvGamma_n);
            else%same coefficients for real and imag parts
                var_meas = zeros(nmeas,1);
                select = self.vincl;%1:nmeas;
                %Calculating the model variance of the noise
                %Constant noise for all measurements:
                var_meas = (meas_noise_coef_e*(max(max(abs(self.Dmeas)))-min(min(abs(self.Dmeas)))))^2;
                %Noise level relative to the abs of measurement value:
                var_meas = var_meas + (meas_noise_coef2*(abs(self.Dmeas) - min(min(abs(self.Dmeas))))).^2;
                %Assume no cross-correlations, hence a diagonal covariance mat:
                Gamma_n = diag(var_meas(:));
                self.InvGamma_n = sparse(inv(Gamma_n));
                self.Ln = chol(self.InvGamma_n);%Store both invGamma and it's Cholesky
            end %end checking complex or real coefficients
        end % end SetInvGamma
        
        
        %===============================================================
        %Here are the derivatives:
        function [Hess, grad] = GetHessAndGrad(self, sigma)
            %Calculate the Hess-matrix and gradient used in solving the
            %inverse problem. This function is called by the inverse
            %problem solver (e.g. SolverLinesearch.m)
            
            
            J = self.FullJacobian(sigma);
            Hess = J'*self.InvGamma_n*J;%First order approximation of the forward problem
            fres = self.SolveForwardVec(sigma);
            grad = J'*self.InvGamma_n*(fres - self.Dmeas);
            
        end
        function J = FullJacobian(self, sigma)
            %Calculate the Jacobian of the forward problem at sigma            
            
            J = self.Jacobian(sigma);
            if length(self.scales) == 2%The scaling done before solving the FEM has to be taken into account here.
                J(:,1:end/2) = J(:,1:end/2)*self.scales(1);
                J(:,end/2+1:end) = J(:,end/2+1:end)*self.scales(2);
            else
                J = J*diag(self.scales);%The scaling done before solving the FEM has to be taken into account here.
            end
            
        end
        function J = Jacobian(self, sigma)
            %Calculate the Jacobian of the forward problem at sigma with
            %injection frequency omega. For info on mode and meshtype see
            %function SolveForward
            
            elval = self.SolveForward(sigma, 1);%This elval may be inaccurate since noscf=1, but the values are not used anywhere
            %if exist('Jacobian3dECTmx.mexw64')
            if 0==1%Using the mex function is currently disabled for easier debugging
                Jleft = -full(self.QC/self.A);%Using the mex function requires some pre-processing
                tempStruct.C = self.QC;
                tempStruct.Electrode = Iel;
                tempStruct.Pot = self.Pot(1:self.ng, :);
                tempStruct.PotF = self.Pot;
                Js = Jacobian3dECTmx(self.Ai, self.Av, Jleft, tempStruct);
            else
                Js = self.Jacobian3dECT(elval);
            end
            Js = Js(self.vincl,:);%some post processing of the Jacobian
            J = self.fmesh.JacobianFtoI(Js);
            
            
            %The final output format of J is governed mainly by three
            %variables in self: absMeas, stackOutput, and self.nginv (or
            %length(sigma) compared to that, i.e. is input stacked?).
            
            if self.stackOutput
                if length(sigma) == 2*self.fmesh.nginv%a complex stacked model
                    J = [real(J) -imag(J); imag(J) real(J)];
                elseif any(~isreal(sigma))% a complex non-stacked model (TODO this is not yet implemented)
                    error('Non-stacked complex sigma is not supported with stacked output.\nThis would require the stacking done after calculating the gradient.');
                else %only real values in sigma, but still want stacked model?
                    warning('real valued sigma, but complex stacked output required, are you sure?');
                    J = [J; zeros(size(J))];
                end
            end
        end
        
        function Js = Jacobian3dECT(self, elval)
            % Computes the Jacobian J = d(measurements) / d(sigma)
            % Original CEM-ECT version written by K. Karhunen 03.06.2013 is implementation
            % from the earlier versions by V. Rimpil�inen(?) and L. M. Heikkinen.
            % Current version adapted for use by P. Kuusela 15.11.2021
            b = length(self.Ai);
            c = size(elval,1); 
            d = size(self.Pot,2); 

            Jleft  = -self.QC/self.A;

            Jright = self.Pot;

            Js = zeros(c*d,b);

            for ii=1:b
              Jid = self.Ai{ii};

              Jtemp   = Jleft(:,Jid)*self.Av{ii}*Jright(Jid,:);
              Js(:,ii) = Jtemp(:);
            end
        end
        
        
        
        function SwapMode(self)
            
            tempmeas = self.IDmeas;
            self.IDmeas = self.Dmeas;
            self.Dmeas = tempmeas;
            if strcmp(self.mode, 'potential')
                self.mode = 'current';
            elseif strcmp(self.mode, 'current')
                self.mode = 'potential';
            else
                error(['Unrecognized solver mode: ' self.mode]);
            end
            
        end
        
        function sigma = LiftSigma(self, sigma)
            if length(sigma) == 2*self.fmesh.nginv %In this case we assume that first half is the real part and second half is the imag part
                if length(self.scales) == 2%Assume that first value is for real and second value for imag scaling
                    sigma = [sigma(1:end/2)*self.scales(1); sigma(end/2+1:end)*self.scales(2)];
                else
                    sigma = sigma.*self.scales;
                end
                if length(self.sigmamin) < 2%If only one sigmamin has been given, duplicate it
                    self.sigmamin = [self.sigmamin; self.sigmamin];
                end
                sigma((1:end<=end/2)' & sigma < self.sigmamin(1)) = self.sigmamin(1);
                sigma((1:end>end/2)' & sigma < self.sigmamin(2)) = self.sigmamin(2);
                sigma = sigma(1:end/2) + 1i*sigma(end/2+1:end);
            else%non-stacked sigma
                if length(self.scales) == 2%Assume that first value is for real and second value for imag scaling
                    sigma = real(sigma)*self.scales(1) + 1i*imag(sigma)*self.scales(2);
                else
                    sigma = sigma.*self.scales;
                end
                if any(~isreal(sigma))%Complex conductivity given
                    if length(self.sigmamin) < 2
                        self.sigmamin = [self.sigmamin; self.sigmamin];
                    end
                    rsigma = real(sigma);
                    isigma = imag(sigma);
                    rsigma(rsigma<self.sigmamin(1)) = self.sigmamin(1);
                    isigma(isigma<self.sigmamin(2)) = self.sigmamin(2);
                    sigma = rsigma + 1i*isigma;
                else
                    sigma(sigma<self.sigmamin) = self.sigmamin;
                end
            end %End checking sigma structure and lifting negative/small values
            
        end
        
        
        %% Plotter functions
        %Plotter functions
        function Plot(self, sigma)
            %Used to plot how the FEM results fit with the measurement data
            
            elval = self.SolveForwardVec(sigma);
            if any(~isreal(elval)) || any(~isreal(self.Dmeas))%There are complex values to plot
                plot(1:length(elval), real(elval), 'r--', 1:length(self.Dmeas), real(self.Dmeas), 'b--', ...
                     1:length(elval), imag(elval), 'r:', 1:length(self.Dmeas), imag(self.Dmeas), 'b:');
                 legend('Forward(real)', 'Measurement(real)', 'Forward(imag)', 'Measurement(imag)');
            else
                plot(1:length(elval), elval, 'r-', 1:length(self.Dmeas), self.Dmeas, 'b-');
                legend('Forward', 'Measurement');
            end
        end
        
        %% Convex optimization
        %These are outdated!!!
        %Stuff required for convex optimization methods for solving the
        %inverse problem (e.g. Chambolle-Pock).
        
        function J = matrix(self, sigest)
            
            if ~isempty(self.lastSigmaJ) && ~any((sigest == self.lastSigmaJ) == 0)
                J = self.lastJ;
            else
                J = self.JacobianSolvingCurrents(sigest);
                %The lines below should make the Chambolle-Pock converge
                %much quicker (based on empirical observations only)
                %J = J'*inv(J*J'+eye(240)*1e-8);
                %J = J';
                self.lastJ = J;
                self.lastSigmaJ = sigest;
            end
        end
        function res = Fproximal(self, d, s)
            res = (d - s*self.Imeas)/(1+s);
        end
        function res = nextDual(self, d, s, sigest2)
            res = d + s*self.SolveElectrodeCurrentsVec(sigest2);
        end     
        
        
        
    end
    
end