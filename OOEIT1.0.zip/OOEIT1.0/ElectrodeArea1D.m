function int=ElectrodeArea1D(g)

int = sqrt((g(1,1)-g(2,1))^2 + (g(1,2)-g(2,2))^2);


end
