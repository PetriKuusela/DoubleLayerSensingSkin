function J = Jacobian3dECT(Ai,Av,A,Qref)
% Computes the Jacobian: J = d_Q / d_epsilon
% Works in 2d and 3d

% This new CEM-ECT version written by K. Karhunen 03.06.2013 is implementation
% from the earlier versions by V. Rimpil�inen and L. M. Heikkinen.
 

b = length(Ai);
c = size(Qref.Electrode,1); 
d = size(Qref.Pot,2); 

if isfield(Qref,'Afield') && ~isempty(Qref.Afield)
  Jleft = Qref.Afield;
else  
  Jleft  = -Qref.C/A;
end

Jright = Qref.Pot;

clear Qref


% J almost always full matrix: use zeros() instead of sparse()
J = zeros(c*d,b);

for ii=1:b
  Jid = Ai{ii};
  
  Jtemp   = Jleft(:,Jid)*Av{ii}*Jright(Jid,:);
  J(:,ii) = [Jtemp(:)];
end

% done
return

