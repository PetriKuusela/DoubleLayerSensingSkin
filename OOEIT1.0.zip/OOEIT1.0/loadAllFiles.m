function M=loadAllFiles(filelist)

M=[];
for i=1:length(filelist)
    disp('-------------------')
    disp(filelist(i))
    disp([num2str(i/length(filelist)*100), ' %'])
    Mtmp=load(filelist{i});
    M=[M ; Mtmp];
end

