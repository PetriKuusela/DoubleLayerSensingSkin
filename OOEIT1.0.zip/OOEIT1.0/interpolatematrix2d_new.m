function M = interpolatematrix2d_new(H,g,p)
% 
% Finds values in arbitrary points (x,y) on a given surface.
% The surface is defined by a triangulation of the data points
% obtained from DELAUNAY.
%
% Output:
%  f ... Interpolated values for points defined in the L-by-2 matrix p
%
% Input:
%  H ... Surface triangulation. M-by-3 "face matrix".
%  g ... Nodal cordinates for H. N-by-2 matrix.
%  f0 .. Data values for each point (row) in the g matrix
%  p ... Coordinates for the interpolation. L-by-2 matrix

% K. Karhunen, 26.04.2008
% Modified by Aku Seppanen 20.2.2013
% Modified by Petri Kuusela 17.9.2021

%Use this: https://mathworld.wolfram.com/TriangleInterior.html
v0 = g(H(:,1),:);
v1 = g(H(:,2),:) - v0;
v2 = g(H(:,3),:) - v0;
a = (p(:,1)*v2(:,2)' - p(:,2)*v2(:,1)' - repmat((v0(:,1).*v2(:,2)-v0(:,2).*v2(:,1))',size(p,1),1))./repmat((v1(:,1).*v2(:,2)-v1(:,2).*v2(:,1))',size(p,1),1);
b = -(p(:,1)*v1(:,2)' - p(:,2)*v1(:,1)' - repmat((v0(:,1).*v1(:,2)-v0(:,2).*v1(:,1))',size(p,1),1))./repmat((v1(:,1).*v2(:,2)-v1(:,2).*v2(:,1))',size(p,1),1);
%b = -(p(:,1)*g(H(:,2),2)' - p(:,2)*g(H(:,2),1)' - repmat((g(H(:,1),1).*g(H(:,2),2)-g(H(:,1),2).*g(H(:,2),1))',size(p,1),1))./repmat((g(H(:,2),1).*g(H(:,3),2)-g(H(:,2),2).*g(H(:,3),1))',size(p,1),1);
insides = a>0 & b>0 & a+b<1-1e-12;
T = zeros(size(p,1), 1);
for ip = 1:size(p,1)
    temp = find(insides(ip,:));
    if length(temp) > 1
        error('a point is inside several triangles!');
    elseif isempty(temp)
        T(ip) = nan;
    else
        T(ip) = temp;
    end
end
nT = length(T);

p = p';
L = [-1 -1;1 0;0 1];
f = zeros(nT,1);

M = sparse(size(p,2),size(g,1));

for ii=1:nT
  iH = T(ii);
  
  if ~isnan(iH)
    id = H(iH,:);
    gg = g(id,:)';
  
    %X = inv(gg*L)*(p(:,ii)-gg(:,1));
    X = (gg*L)\(p(:,ii)-gg(:,1));
    %f(ii) = f0(id)'*[1-X(1)-X(2);X];

    M(ii,id) = M(ii,id) + [1-X(1)-X(2), X(1), X(2)];
  else
    dist_to_nearest = 1e9;
    nearest = 0;
    for j=1:size(g,1)
        dist = sqrt((p(1,ii)-g(j,1)).^2+(p(2,ii)-g(j,2)).^2);
        if(dist<dist_to_nearest)
            dist_to_nearest = dist;
            nearest = j;
        end
    end
    M(ii,nearest) = M(ii,nearest) + 1;
  end  
end
return
