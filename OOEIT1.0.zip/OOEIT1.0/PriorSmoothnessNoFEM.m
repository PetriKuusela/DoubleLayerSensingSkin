classdef PriorSmoothnessNoFEM < handle
%PriorSmoothness class contains a smoothness prior and the required functions
%for it to be called by an inverse problem solver -class (e.g.
%SolverLinesearch.m).
%
%Supports real values, complex values, or a stacked complex model
%(where input is [real(sigma); imag(sigma)]). To enable using stacked
%model, the mean has to have 2 elements or twice the length of ginv.
%
%Supports 2D and 3D meshes (3D has not been tested though...).
%
%Author: Petri Kuusela 16.11.2021
    
    
    properties
        invcov  %The inverse of the covariance matrix
        mean    %The expectation value of the estimate (can be a single value or a vector with same length as ginv)
        L       %chol(invcov), used only to draw samples from the prior
        regularization_c %A regularization constant to make sure the covariance matrix is not poorly conditioned
        common_c %A constant added to all the elements of the covariance matrix. Larger values allow greater variation in the mean value of the estimate
    end
    
    
    methods
        
        function obj = PriorSmoothnessNoFEM(ginv, corlen, var, mean)
            %Class constructor.
            %Input: ginv = the nodes of the reconstruction mesh
            %       corlen = the correlation length (length where the
            %               cross-covariance has decreased to 1%)
            %       var = the variance of the values of the estimate
            %       mean = the expectation value of the estimate. Can be a
            %       single value or a vector with same length as ginv for a
            %       non-stacked model, and two values or twice the length
            %       of ginv for a stacked model (i.e. where the estimate is
            %       [real(sigma);imag(sigma)])
            
            obj.regularization_c = 1e-4;
            obj.common_c = 1e-1;
            if length(mean) == 2 || length(mean) == 2*length(ginv)%Stacked model
                obj.SetCovMat(ginv, corlen, var, 1);
            else%non-stacked model
                obj.SetCovMat(ginv, corlen, var, 0);
            end
            obj.mean = mean;
            obj.L = chol(obj.invcov);
        end
        
        function SetCovMat(self, g, corlen, var, stacked)
            %Compute the inverse covariance matrix given the input
            %parameters. 
            %Input: g = node coordinates
            %       corlen = spatial correlation length (length where the
            %               cross-covariance has decreased to 1%)
            %       var = the variance of the estimate values
            %       stacked = A flag: create a stacked model?
            
            if stacked%Stacked model
                if length(var) < 2%var can initally have 1 or 2 elements, after this it has 2.
                    var = [var;var];
                end
                ng = size(g,1);
                b = corlen./sqrt(2*log(100));
                c = self.regularization_c*var;
                a = var-c;
                xmat = repmat(g(:,1),1,ng);
                ymat = repmat(g(:,2),1,ng);
                zmat = 0;
                if size(g,2) > 2%if the mesh is 3D
                    zmat = repmat(g(:,2),1,ng);
                end
                if length(b) < 2
                    b = [b;b];
                end
                cov1 = a(1)*exp(-0.5*((xmat-xmat').^2+(ymat-ymat').^2+(zmat-zmat').^2)/b(1)^2);%these are the basic covariance matrices
                cov2 = a(2)*exp(-0.5*((xmat-xmat').^2+(ymat-ymat').^2+(zmat-zmat').^2)/b(2)^2);
                cov1 = cov1 + diag(c(1)*ones(size(cov1,1),1)) + self.common_c*var(1)*ones(size(cov1,1));%modify them by adding reagularization on the diagonal
                cov2 = cov2 + diag(c(2)*ones(size(cov2,1),1)) + self.common_c*var(2)*ones(size(cov2,1));%and a common term to all elements
                invcov1 = inv(cov1);
                invcov2 = inv(cov2);
                self.invcov = [invcov1 zeros(ng); zeros(ng) invcov2];
            else%not a stacked model
                ng = size(g,1);
                b = corlen./sqrt(2*log(100));
                c = self.regularization_c*var;
                a = var-c;
                xmat = repmat(g(:,1),1,ng);
                ymat = repmat(g(:,2),1,ng);
                zmat = 0;
                if size(g,2) > 2%if the mesh is 3D
                    zmat = repmat(g(:,2),1,ng);
                end
                cov = a*exp(-0.5*((xmat-xmat').^2+(ymat-ymat').^2+(zmat-zmat').^2)/b^2);
                cov = cov + diag(c(1)*ones(size(cov,1),1)) + self.common_c*var(1)*ones(size(cov,1));
                self.invcov = inv(cov);
            end
        end
        
        function res = OptimizationFunction(self, sigest)
            %This function is called by the inverse problem solver, and it
            %gives the function value to be minimized.
            sigest = sigest(1:size(self.invcov,1));
            if any(~isreal(sigest))%Transform a non-stacked complex model into the stacked form
                sigest = [real(sigest);imag(sigest)];
            end
            res = 0.5*(sigest-self.mean)'*self.invcov*(sigest-self.mean);
        end
        
        function [Hess, grad] = GetHessAndGrad(self, sigest)
            %This function is called by the inverse problem solver, and it
            %gives the Hess-matrix and gradient of the optimization
            %function.
            sigmasize = length(sigest);
            sigest = sigest(1:size(self.invcov,1));
            nonstacked = 0;
            if any(~isreal(sigest))%Transform a non-stacked complex model into the stacked form
                sigest = [real(sigest);imag(sigest)];
                nonstacked = 1;
            end
            grad = self.invcov*(sigest-self.mean);
            Hess = self.invcov;
            if nonstacked
                grad = grad(1:end/2) + 1i*grad(end/2+1:end);
                Hess = Hess(1:end/2,1:end/2) + 1i*Hess(end/2+1:end,end/2+1:end);
            end
            grad = [grad; zeros(sigmasize-size(self.invcov,1),1)];
            Hess = [sparse(Hess) sparse(size(self.invcov,1), sigmasize-size(self.invcov,1)); sparse(sigmasize-size(self.invcov,1),size(self.invcov,1)) sparse(sigmasize-size(self.invcov,1),sigmasize-size(self.invcov,1))];
        end
        
        
    end
    
    
    
end