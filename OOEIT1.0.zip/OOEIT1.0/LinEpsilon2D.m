function int=LinEpsilon2D_cylsym(g,sigma);

%planeint Computes the integral of the product of a gradient and a basis function in 2D FEM
% The function int=LinEpsilon2D_cylsym(g,sigma);
% calculates one part in the linear 
% FEM in 2D cylindrical symmetric ECT.
%
% INPUT
%
% g = nodal coordinates
% sigma = conductivity of in nodes of the element
%
% OUTPUT
%
% int = value of the integral 

% A. Nissinen 22.05.2013



w=[1/6*ones(3,1)];
ip=[1/2 0;1/2 1/2;0 1/2];
L=[-1 1 0;-1 0 1];
Jt=L*g;
iJt=inv(Jt);
dJt=abs(det(Jt));
G=iJt*L;
int=0;
for ii=1:3
    S=[1-ip(ii,1)-ip(ii,2) ip(ii,1) ip(ii,2)];
    
    s = S*sigma(:); %%% sigma peruselem
    %int=int+r(1)*w(ii)*G'*G; %%% tassa puuttuu siis jalkimmainen termi
    int=int+s*w(ii)*G'*G;
 end
%int=2*pi*sigma*int*dJt;
int=int*dJt;



%int=1/2*sigma*G'*G*dJt;









