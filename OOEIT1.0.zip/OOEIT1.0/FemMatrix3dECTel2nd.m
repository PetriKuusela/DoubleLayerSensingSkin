function [A,B,M] = FemMatrix3dECTel2nd(g,E,zeta,Inj,C)

Nel = size(Inj,1);

nI = size(Inj,2);
ng = size(g,1);

B = zeros(ng+Nel-1,nI);
s = zeros(Nel,nI);

len = 0;
for ii=1:Nel
  len = len + length(E{ii});
end
len3 = 6*len;

intS = zeros(len3,6);
intM = zeros(len,6);
rowS = zeros(len3,6);
rowM = zeros(len,6);
colS = zeros(len3,6);
colM = zeros(len,6);


mpos = 1;
spos = 1;
oldpos = 1;

% Loop through electrodes
for ii=1:Nel
  faces = E{ii};
    
  % Loop through faces on electrode ii
  for jj = 1:size(faces,1),
    ind = faces(jj,:); % face nodes
    
    gg = g(ind,:);
    %keyboard
    rcidx = [ind;ind;ind;ind;ind;ind];
    
    bb1 = triang2nd1(gg);
    bb2 = triang2nd2(gg);
    
    intS(spos:spos+5,:) = bb2/zeta(ii);
    rowS(spos:spos+5,:) = rcidx.'; 
    colS(spos:spos+5,:) = rcidx;   

    intM(mpos,:) = -bb1.'/zeta(ii);
    colM(mpos,:) = ind; 
    
   
    B(ind,:) = B(ind,:) + bb1*Inj(ii,:)/zeta(ii);
    s(ii,:)  = s(ii,:) - elektro2nd(gg)*Inj(ii,:)/zeta(ii);
    
    spos = spos + 6;
    mpos = mpos + 1;    
  end
  rowM(oldpos:mpos-1,:) = ii;  
  oldpos = mpos;
end
S = sparse(rowS,colS,intS,ng,ng+Nel-1);
M = sparse(rowM,colM,intM,Nel,ng);

B(ng+1:end,:) = C'*s;

D = sparse(C'*C);
M = C'*M;
A = [S;M,D];
return
