classdef HomogeneousWrapper < handle
%This is a wrapper class for EITFEM class used for computing the
%homogeneous estimates. It changes the input from being full sigma to just
%two values: conductivity and permittivity.
%Here a stacked model implementation is presumed.
%
%This wrapper might be useless, instead one could use in the
%EITFEM solverP1st = ones(solver.ng,1); Maybe.
    
    
    properties
        solver  %This is the EITFEM object to be wrapped
        ng      %The number of nodes in the inverse mesh
        resistivity%Estimate resistivity instead of conductivity (works better for current injection?)
    end
    
    methods
        
        function obj = HomogeneousWrapper(solver)
            %Class constructor. Input argument is the solver to be wrapped.
            obj.solver = solver;
            if numel(solver.P1st) == 1%This means that the inverse and forward mesh are the same
                obj.ng = solver.ng;
            else%Otherwise we can get the inverse size mesh from solver.P1st
                obj.ng = size(solver.P1st,2);
            end
            obj.resistivity = 0;
        end
        function res = OptimizationFunction(self,hest)
            if self.resistivity
                cr = hest(1) + 1i*hest(2);
                cc = 1/cr;
                hest = [real(cc); imag(cc)];
            end
            res = self.solver.OptimizationFunction([hest(1)*ones(self.ng,1); hest(2)*ones(self.ng,1)]);
        end
        function [Hess, grad] = GetHessAndGrad(self,hest)
            if self.resistivity
                cr = hest(1) + 1i*hest(2);
                cc = 1/cr;
                hest = [real(cc); imag(cc)];
            end
            [Hess, grad] = self.solver.GetHessAndGrad([hest(1)*ones(self.ng,1); hest(2)*ones(self.ng,1)]);
            grad = [sum(grad(1:end/2)); sum(grad(end/2+1:end))];
            Hess = [sum(sum(Hess(1:end/2,1:end/2))) sum(sum(Hess(1:end/2,end/2+1:end)));...
                    sum(sum(Hess(end/2+1:end,1:end/2))) sum(sum(Hess(end/2+1:end,end/2+1:end)))];
            if self.resistivity
                cgrad = grad(1) + 1i*grad(2);
                cgrad = -cgrad./(cc^2);
                grad = [real(cgrad); imag(cgrad)];
                
            end
        end
        function Plot(self,hest)
            %This can be used to plot the fitting of the data during the
            %solving of the homogeneous estimate.
            if self.resistivity
                cr = hest(1) + 1i*hest(2);
                cc = 1/cr;
                hest = [real(cc); imag(cc)];
            end
            self.solver.Plot([hest(1)*ones(self.ng,1); hest(2)*ones(self.ng,1)]);
        end
        
        
    end
    
end