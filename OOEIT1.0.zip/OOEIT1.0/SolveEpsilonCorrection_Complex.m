function [eps, hest] = SolveEpsilonCorrection_Complex(solver, sigmainit, hinit)
    %This function fits a homogeneous estimate (conductivity and 
    %permittivity) to the data of EITFEM-solver, and
    %then proceeds to calculate the epsilon correction (i.e. the
    %difference between the results of FEM and measurements).
    %
    %This function utilizes SolverLinesearch-class to solve the 2D
    %optimization problem.
    %
    %Author: Petri Kuusela 16.11.2021
    
    if nargin < 3
        hinit = [1;1];
    end
    
    
    
    hw = HomogeneousWrapper(solver);
    PosiPrior = PriorPositivityParabolic(1e-9, 1e1);
    resobj = cell(2,1);
    resobj{1} = hw;
    resobj{2} = PosiPrior;
    InvSolver = SolverLinesearch(resobj);
    InvSolver.maxIter = 3;
    InvSolver.plotIterations = 0;
    InvSolver.showSplitVals = 1;
    
    if 0 == 1%strcmp(solver.mode, 'potential')
        solver.mode = 'current';
        solver.Imeas = -solver.Imeas;
        hinit = InvSolver.solve(hinit);%if the initial guess is really far, the solver struggles with mode 'potential'
        InvSolver.maxIter = 3;
        solver.mode = 'potential';
        solver.Imeas = -solver.Imeas;
    end
    
    
    hest = InvSolver.solve(hinit);
    
    if strcmp(solver.mode, 'current')
        Iel = solver.SolveForwardVec([hest(1)*sigmainit(1:end/2);hest(2)*sigmainit(end/2+1:end)]);
        eps = solver.Imeas-Iel;
    elseif strcmp(solver.mode, 'potential')
        Uel = solver.SolveForwardVec([hest(1)*sigmainit(1:end/2);hest(2)*sigmainit(end/2+1:end)]);
        eps = solver.Umeas-Uel;
    else
        error('Unrecognized solver mode');
    end

end